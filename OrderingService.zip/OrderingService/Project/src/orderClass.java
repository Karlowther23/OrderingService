import java.util.Scanner;

public class orderClass extends ProductDB {
	
	public void orderChoice() {
		System.out.println("Enter phone or tv order");
		System.out.println("1 --> for phone");
		System.out.println("2 --> for tv");
		
		Scanner s = new Scanner (System.in);
		int choice = s.nextInt();
		if (choice == 1) {
			phoneOrder();
		}
		else {
			tvOrder();
		}
	}
	
	public void phoneOrder() {
		productClass phoneOrder = new productClass(null, null, 0 , 0);
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number of orders");
        int orderNum = input.nextInt();

        for (int i = 0; i < orderNum; i++) {
        	Scanner s = new Scanner (System.in);  		
            System.out.println("Enter phone: ");
            phoneOrder.setName(s.nextLine()+ " ");
            
            Scanner s1 = new Scanner (System.in);
            System.out.println("Enter description: ");
            phoneOrder.setDes(s1.nextLine()+ " ");
            
            System.out.println("Enter Price: ");
            phoneOrder.setPrice(input.nextDouble());
            
            System.out.println("Enter ID: ");
            phoneOrder.setID(input.nextInt());
            
            System.out.println("Phone Order number " + (i + 1));
            System.out.println("Name:        " + phoneOrder.getName());
    		System.out.println("Description: " + phoneOrder.getDes());
    		System.out.println("Price:       €" + phoneOrder.getPrice());
    		System.out.println("ID:          " + phoneOrder.getID());
    		System.out.println();
    		
    		prodPhone.add(phoneOrder.getName());
    		prodPhoned.add(phoneOrder.getDes());
    		prodPhonep.add(phoneOrder.getPrice());
    		prodPhoneid.add(phoneOrder.getID());
    		
    		
        }  
        
       
        System.out.println("1 --> Phone Order" + "\n2 --> TV order" + "\n3 --> Exit");
        Scanner s = new Scanner (System.in);
		int choice = s.nextInt();
		if (choice == 1) {
			phoneOrder();
		}
		else if (choice == 2) {
			tvOrder();
		}
		else if (choice == 3){
			System.out.println();
			System.out.println("Thank You");
		}
		else {
			System.out.println("Error");
			System.exit(choice);
		}
	}
	
	
	public void tvOrder() {
		tvClass tvOrder = new tvClass(null, null, null, 0 , 0);
		
		Scanner input = new Scanner(System.in);
		System.out.println("Enter number of orders");
        int orderNum = input.nextInt();

        for (int i = 0; i < orderNum; i++) {
        	
            System.out.println("Enter Make: ");
            tvOrder.setMake(input.next() + " ");
            
            System.out.println("Enter Type: ");
            tvOrder.setType(input.next());
            
            System.out.println("Enter 3D Capability: ");
            tvOrder.setThreeD(input.next());
            
            System.out.println("Enter Screen Size: ");
            tvOrder.setScreenSize(input.nextInt());
            
            System.out.println("Enter Price: ");
            tvOrder.setPrice(input.nextInt());
            
            System.out.println("Order number " + (i + 1));
            System.out.println("Make:        " + tvOrder.getMake());
    		System.out.println("Type:        " + tvOrder.getType());
    		System.out.println("3D           " + tvOrder.getThreeD());
    		System.out.println("Screen Size: " + tvOrder.getScreenSize());
    		System.out.println("Price:       €" + tvOrder.getPrice());
    		System.out.println();
    		
    		System.out.println("Tv Order number " + (i + 1));
    		prodTv.add(tvOrder.getMake());
    		prodTvt.add(tvOrder.getType());
    		prodTv3d.add(tvOrder.getThreeD());
    		prodTvs.add(tvOrder.getScreenSize());
    		prodTvp.add(tvOrder.getPrice());
	}
        
        System.out.println();
        System.out.println("1 --> Phone Order" + "\n2 --> TV order" + "\n3 --> Exit");
        Scanner s = new Scanner (System.in);
		int choice = s.nextInt();
		if (choice == 1) {
			phoneOrder();
		}
		else if (choice == 2) {
			tvOrder();
		}
		else if (choice == 3){
			System.out.println();
			System.out.println("Thank You");
		}
		else {
			System.out.println("Error");
			System.exit(choice);
		}
	}
	
	
	public void orders() {
		for (int i = 0; i < prodPhone.size(); i++) {
			System.out.println("Order Number " + (i +1));
			System.out.println();
			System.out.println("Name:        " + prodPhone.get(i));
			System.out.println("Description: " + prodPhoned.get(i));
			System.out.println("Price:       €" + prodPhonep.get(i));
			System.out.println("ID:          " + prodPhoneid.get(i));
			System.out.println();
			 
		 }
	}
	
	public void searchID() {
		int a = 0;
		Scanner s  = new Scanner(System.in);
		System.out.println("Enter product ID: ");
		int idNum = s.nextInt();
		
		for (int o = 0; o < prodPhoneid.size(); o++) {
			if (idNum == prodPhoneid.get(a)) {
				for (int i = 0; i < prodPhoneid.size(); i++) {
			
			System.out.println();
			System.out.println("Order Number " + (i + 1));
			System.out.println();
			System.out.println("Name:        " + prodPhone.get(i));
			System.out.println("Description: " + prodPhoned.get(i));
			System.out.println("Price:       €" + prodPhonep.get(i));
			System.out.println("ID:          " + prodPhoneid.get(i));
			}
		}
		else if (idNum != prodPhoneid.get(a)) {
			System.out.println("Wrong ID, we can try again");
			System.out.println("1 --> to try again");
			System.out.println("2 --> to quit");
			Scanner option = new Scanner (System.in);
			int choice = option.nextInt();
			if (choice == 1) {
			searchID();
			}
			else if (choice == 2) {
				System.out.println("Back to the menu");
			}
		}
		else {
			System.out.println("Error");
		}
		}
		System.out.println();
		System.out.println("Back to the menu");
	}
}


