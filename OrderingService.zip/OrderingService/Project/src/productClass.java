import java.util.Scanner;

public class productClass extends ProductDB {
	private String name;
	private String description;
	private double price;
	private int ID;
	
	
	public productClass(String a, String b, double c, int d) {
		setName(a);
		setDes(b);
		setPrice(c);
		setID(d);
	}

	void setName(String a){
		name = a;
	}
	
	void setDes(String b) {
		description = b;
	}
	
	void setPrice(double c) {
		price = c;
	}
	
	void setID(int d) {
		ID = d;
	}
	
	String getName(){
		return name;
	}
	
	String getDes() {
		return description;
	}
	
	double getPrice() {
		return price;
	}
	
	int getID() {
		return ID;
	}
	
	
	public String toString(){
		String all = "Name: " + name + "\nDescription: " + description + "\nPrice: " + price + "\nID: " + ID;
		return all;
		}
	
	void print() {
		productClass newPhone = new productClass(name, description, price, ID);
		
		Scanner s = new Scanner (System.in);
		System.out.println("Enter type of Phone");
		newPhone.setName(s.nextLine()+ " ");
		
		Scanner s1 = new Scanner (System.in);
		System.out.println("Enter description of phone");
		newPhone.setDes(s1.nextLine()+ " ");
		
		Scanner s2 = new Scanner (System.in);
		System.out.println("Enter price");
		newPhone.setPrice(s2.nextDouble());
	
		double randomDouble = Math.random();
		randomDouble = randomDouble * 1000000 + 1;
		int randomInt = (int) randomDouble;
		
		ID = randomInt;
		
	    
		String all = "Name: " + name + "\nDescription: " + description + "\nPrice: €" + price + "\nID: " + ID;
		System.out.println();
		System.out.println("Name:        " + newPhone.getName());
		System.out.println("Description: " + newPhone.getDes());
		System.out.println("Price:       €" + newPhone.getPrice());
		System.out.println("ID:          " + randomInt);
		System.out.println();
		
		
		phoneN.add(newPhone.getName());
		phoneD.add(newPhone.getDes());
		phoneP.add(newPhone.getPrice());
		phoneInt.add(randomInt);
		
	}
	
}
