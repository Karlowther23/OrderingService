import java.util.Scanner;

public class TestClass extends ProductDB {

	public static void main(String[] args) {
		System.out.println("Please Choose from below");
		System.out.println("1 --> Create New Phone.");
		System.out.println("2 --> Create New Customer.");
		System.out.println("3 --> Search for a product by supplying the productID.");
		System.out.println("4 --> Display all products in the database.");
		System.out.println("5 --> Allow a customer to order some products.");
		System.out.println("6 --> Display all orders that a customer has made and all the products that are in a given order");
		System.out.println("7 --> Display all orders for a given product by supplying the product ID.");
		System.out.println("8 --> Quit.");
		
		Scanner s = new Scanner(System.in);
		int press = s.nextInt();
		
		if (press == 1) {
			productClass product = new productClass(null, null, press, press);
			System.out.println();
			product.print();
			System.out.println("");
			main(args);
		
		}
		else if (press == 2) {
			customerClass customer = new customerClass(null, null);
			customer.info();
			System.out.println();
			main(args);
		}
		else if (press == 3) {
			ProductDB id = new ProductDB();
			id.idShowings();
			System.out.println();
			main(args);
		}
		else if (press == 4) {
			ProductDB product = new ProductDB();
			product.menu();
			System.out.println();
			main(args);
			
		}
		else if (press == 5) {
			orderClass order = new orderClass();
			order.orderChoice();
			System.out.println();
			main(args);
		}
		else if (press == 6) {
			orderClass prod = new orderClass();
			prod.orders();
			main(args);
		}
		else if (press == 7) {
			orderClass orders = new orderClass();
			orders.searchID();
			System.out.println();
			main(args);
		}
		else if (press == 8) {
			System.out.println("GoodBye");
			System.exit(0);
		}
		
		else{
			System.out.println("Error, try again");
			System.out.println();
			main(args);
		}
		
	}

}
