
public class phoneClass extends productClass{
	public phoneClass(String a, String b, double c, int d) {
		super(a, b, c, d);
	}

	private String make;
	private String model;
	private int storage;
	
	void phoneClass(String a, String b, int c) {
		setMake(a);
		setModel(b);
		setStorage(c);
	}
	
	void setMake(String a) {
		make = a;
	}
	
	void setModel(String b) {
		model = b;
	}
	void setStorage(int c) {
		storage = c;
	}
	
	String getMake() {
		return make;
	}
	
	String getModel() {
		return model;
	}
	
	int getStorage() {
		return storage;
	}
	
}
