import java.util.Scanner;

public class customerClass extends ProductDB{
	private String name;
	private String address;
	 
	 public customerClass(String a, String b) {
		 setName(a);
		 setAddress(b);
	 }


	 void setName (String a) {
		 name = a;
	 }

	 void setAddress (String b) {
		 address = b;
	}

	 String getName () {
		 return name;
	 }

	 String getAddress () {
		 return address;
	 }
	 
	 public String toString(){
		 String all = "Name: " + name + "\nAddress: " + address;
		 return all;
	}
	 
	public void info() {
		customerClass customer = new customerClass(null, null);
		
		Scanner s = new Scanner (System.in);
		System.out.println("Enter name: ");
		customer.setName(s.nextLine()+ " ");
    
		Scanner s1 = new Scanner (System.in);
		System.out.println("Enter address: ");
		customer.setAddress(s.nextLine()+ " ");
		
		String all = "Name: " + name + "\nAddress: " + address;
		System.out.println("Name:        " + customer.getName());
		System.out.println("Address: 	" + customer.getAddress());
		System.out.println();
		
		cName.add(customer.getName());
		cAdd.add(customer.getAddress());
		
	}
}