
public class tvClass {
	
	private String make;
	private String type;
	private String threeD;
	private int screenSize;
	private double price;
	
	public tvClass(String a, String b, String c, int d, double e) {
		setMake(a);
		setType(b);
		setThreeD(c);
		setScreenSize(d);
		setPrice(e);
	}
	void setMake(String a) {
		make = a;
	}
	void setType(String b) {
		type = b;
	}
	void setThreeD(String c) {
		threeD = c;
	}
	void setScreenSize(int d) {
		screenSize = d;
	}
	void setPrice(double e) {
		price = e;
	}
	
	String getMake() {
		return make;
	}
	
	String getType() {
		return type;
	}
	
	String getThreeD() {
		return threeD;
	}
	
	int getScreenSize() {
		return screenSize;
	}
	
	double getPrice() {
		return price;
	}
	
	public String toString(){
		String all = "Make: " + make + "\nType: " + type + "\nScreenSize: " + screenSize + "\n3D: " + threeD + "\nPrice: €" +price;
		return all;
		}
	
	public void print() {
		String all = "Make: " + make + "\nType: " + type + "\nScreenSize: " + screenSize + "\n3D: " + threeD + "\nPrice: €" +price;
		System.out.println();
		System.out.println("Make:  " + make);
		System.out.println("Type:  " + type);
		System.out.println("Size:  " + screenSize);
		System.out.println("3D:    " + threeD);
		System.out.println("Price €" + price);
	}
}
