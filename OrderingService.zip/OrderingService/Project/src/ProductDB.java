import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ProductDB{
	
	static List <String> prodPhone = new ArrayList<String>();
	static List<String> prodPhoned = new ArrayList<String>();
	static List<Double> prodPhonep= new ArrayList<Double>();
	static List <Integer> prodPhoneid= new ArrayList<Integer>();
	
	static List <String> cName = new ArrayList<String>();
	static List <String> cAdd = new ArrayList<String>();
	
	static List <String> phoneN = new ArrayList<String>();
	static List <String> phoneD = new ArrayList<String>();
	static List <Double> phoneP = new ArrayList<Double>();
	static List <Integer> phoneInt = new ArrayList<Integer>();
	
	static List<String> prodTv = new ArrayList<String>();
	static List<String> prodTvt = new ArrayList<String>();
	static List<String> prodTv3d = new ArrayList<String>();
	static List<Integer> prodTvs = new ArrayList<Integer>();
	static List<Double> prodTvp = new ArrayList<Double>();
	
	String formattedString = prodPhone.toString()
			.replace(",", "")
		    .replace("[", "") 
		    .replace("]", "")
		    .trim();
	
	
	public void menu() {
		Scanner s = new Scanner(System.in);
		System.out.println("Please choose option");
		System.out.println("1 --> Search with ID");
		System.out.println("2 --> Show full database");
		int choice = s.nextInt();
		if (choice == 1) {
			idShowings();
		}
		else if (choice == 2) {
			info();
		}
		else {
			
		}
	}
	
	public void info() {
		phoneClass phone1 = new phoneClass("iPhone XR", "64GB",850.00, 190857);
		phoneClass phone2 = new phoneClass("Google Pixle", "64GB",650.00, 296420);
		phoneClass phone3 = new phoneClass("Samsung Galaxy S9 Plus", "32GB",800.00, 672361);
		phoneClass phone4 = new phoneClass("Huawei Mate 20 Pro", "32GB",450.00, 584734);
		phoneClass phone5 = new phoneClass("OnePlus 6T", "64GB",700.00, 927362);
		
		System.out.println();
		System.out.printf(phone1 + "\n\n"  + phone2 + "\n\n" + phone3 + "\n\n" + phone4 + "\n\n" + phone5 + "\n");
		System.out.println();
		
		tvClass tv1 = new tvClass("Phillips","Full HD Ultra Slim LED TV","No", 43, 380.00);
		tvClass tv2 = new tvClass("Blue Diamond","LED Full HD TV","No", 55, 465.20);
		tvClass tv3 = new tvClass("Samsung","Ultra HD Smart 4K TV","No", 55, 780.80);
		tvClass tv4 = new tvClass("Samsung","Ultra HD Smart 4K TV","Yes", 65, 900.00);
		tvClass tv5 = new tvClass("Sony","4K Ultra HD 120Hz Smart LED TV","Yes", 75, 1299.99);

		System.out.println();
		System.out.printf(tv1 + "\n\n"  + tv2 + "\n\n" + tv3 + "\n\n" + tv4 + "\n\n" + tv5 + "\n");
		System.out.println();
		return;
	}
	
	public void inputtedInfo() {
		for (int i = 0; i < phoneN.size(); i++) {
			System.out.println("Order Number " + (i +1));
			System.out.println();
			System.out.println("Name:        " + phoneN.get(i));
			System.out.println("Description: " + phoneD.get(i));
			System.out.println("Price:       €" + phoneP.get(i));
			System.out.println("ID:          " + phoneInt.get(i));
			System.out.println();
			 
		 }
	}
	
	public void idShowings() {
		int i = 0;
		productClass newPhone = new productClass(formattedString, formattedString, i, i);
		
		phoneClass phone1 = new phoneClass("iPhone XR", "64GB",850.00, 190857);
		phoneClass phone2 = new phoneClass("Google Pixle", "64GB",650.00, 296420);
		phoneClass phone3 = new phoneClass("Samsung Galaxy S9 Plus", "32GB",800.00, 672361);
		phoneClass phone4 = new phoneClass("Huawei Mate 20 Pro", "32GB",450.00, 584734);
		phoneClass phone5 = new phoneClass("OnePlus 6T", "64GB",700.00, 927362);
		Scanner s = new Scanner(System.in);
		System.out.println("Enter ID: ");
		int id = s.nextInt();
		if (id == 190857) {
			System.out.println(phone1);
		}
		else if(id == 296420) {
			System.out.println(phone2);
		}
		else if(id == 672361) {
			System.out.println(phone3);
		}
		else if(id == 584734) {
			System.out.println(phone4);
		}
		else if(id == 927362) {
			System.out.println(phone5);
		}
		else if(id == phoneInt.get(i)) {
			System.out.println("Name:        " + phoneN.get(i));
			System.out.println("Description: " + phoneD.get(i));
			System.out.println("Price:       €" + phoneP.get(i));
			System.out.println("ID:          " + phoneInt.get(i));
			System.out.println();
		}
		else {
			System.out.println("There seems to be an issue.");
			System.out.println("We will return you to the menu.");
		}
	}
}
